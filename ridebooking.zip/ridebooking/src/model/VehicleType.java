package model;

public enum VehicleType {
    BIKE,
    AUTO,
    CAR
}
