package model;

public enum RideStatus {
    REQUESTED,
    ASSIGNED,
    COMPLETED,
    CANCELLED
}
