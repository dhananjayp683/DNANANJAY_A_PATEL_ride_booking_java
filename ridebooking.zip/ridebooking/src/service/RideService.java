package service;

import model.*;
import strategy.FareStrategy;
import strategy.RideMatchingStrategy;
import java.util.ArrayList;
import java.util.List;

public class RideService {

    private final RideMatchingStrategy matchingStrategy;
    private final FareStrategy fareStrategy;
    private final List<Ride> rides = new ArrayList<>();
    private int rideIdCounter = 1;

    public RideService(RideMatchingStrategy matchingStrategy, FareStrategy fareStrategy) {
        this.matchingStrategy = matchingStrategy;
        this.fareStrategy = fareStrategy;
    }

    public Ride requestRide(Rider rider, List<Driver> drivers, double distance) {
        Ride ride = new Ride(rideIdCounter++, rider, distance);
        Driver driver = matchingStrategy.findDriver(rider, drivers);

        if (driver != null) {
            driver.setAvailable(false);
            ride.assignDriver(driver);
        }

        rides.add(ride);
        return ride;
    }

    public FareReceipt completeRide(int rideId) {
        Ride ride = rides.stream()
                .filter(r -> r.getId() == rideId)
                .findFirst()
                .orElse(null);

        if (ride == null) return null;

        ride.complete();
        ride.getDriver().setAvailable(true);

        double fare = fareStrategy.calculateFare(ride);
        return new FareReceipt(rideId, fare);
    }

    public List<Ride> getAllRides() {
        return rides;
    }
}
