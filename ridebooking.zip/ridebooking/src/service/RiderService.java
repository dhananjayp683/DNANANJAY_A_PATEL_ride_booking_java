package service;

import model.Rider;
import java.util.HashMap;
import java.util.Map;

public class RiderService {
    private final Map<Integer, Rider> riders = new HashMap<>();

    public void registerRider(Rider rider) {
        riders.put(rider.getId(), rider);
    }

    public Rider getRider(int id) {
        return riders.get(id);
    }
}
