package strategy;

import model.Driver;
import model.Rider;
import java.util.List;

public class LeastActiveDriverStrategy implements RideMatchingStrategy {

    @Override
    public Driver findDriver(Rider rider, List<Driver> drivers) {
        return drivers.stream()
                .filter(Driver::isAvailable)
                .reduce((first, second) -> first)
                .orElse(null);
    }
}
