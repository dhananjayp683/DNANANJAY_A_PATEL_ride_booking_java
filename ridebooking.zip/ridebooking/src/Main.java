import model.*;
import service.*;
import strategy.*;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        RiderService riderService = new RiderService();
        DriverService driverService = new DriverService();

        RideService rideService = new RideService(
                new NearestDriverStrategy(),
                new DefaultFareStrategy()
        );

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Add Rider");
            System.out.println("2. Add Driver");
            System.out.println("3. View Available Drivers");
            System.out.println("4. Request Ride");
            System.out.println("5. Complete Ride");
            System.out.println("6. View Rides");
            System.out.println("7. Exit");

            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1 -> {
                        System.out.print("Rider ID: ");
                        int id = sc.nextInt();
                        System.out.print("Name: ");
                        String name = sc.next();
                        System.out.print("Location: ");
                        String loc = sc.next();
                        riderService.registerRider(new Rider(id, name, loc));
                    }

                    case 2 -> {
                        System.out.print("Driver ID: ");
                        int id = sc.nextInt();
                        System.out.print("Name: ");
                        String name = sc.next();
                        System.out.print("Location: ");
                        String loc = sc.next();
                        driverService.registerDriver(new Driver(id, name, loc));
                    }

                    case 3 -> driverService.getAvailableDrivers()
                            .forEach(d -> System.out.println(d.getName()));

                    case 4 -> {
                        System.out.print("Rider ID: ");
                        int rid = sc.nextInt();
                        System.out.print("Distance: ");
                        double dist = sc.nextDouble();
                        Ride ride = rideService.requestRide(
                                riderService.getRider(rid),
                                driverService.getAvailableDrivers(),
                                dist
                        );
                        System.out.println("Ride ID: " + ride.getId());
                    }

                    case 5 -> {
                        System.out.print("Ride ID: ");
                        int id = sc.nextInt();
                        FareReceipt receipt = rideService.completeRide(id);
                        System.out.println(receipt);
                    }

                    case 6 -> rideService.getAllRides()
                            .forEach(r -> System.out.println(
                                    r.getId() + " - " + r.getStatus()));

                    case 7 -> System.exit(0);
                }
            } catch (Exception e) {
                System.out.println("Invalid input!");
            }
        }
    }
}
